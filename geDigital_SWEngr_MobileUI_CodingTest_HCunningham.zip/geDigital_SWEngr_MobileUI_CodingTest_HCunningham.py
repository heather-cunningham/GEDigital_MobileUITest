## Heather Cunningham
## 09/13/18
## GE Digital - Software Engineer, UI & Mobile
## Coding Test


import json
import webbrowser
import urllib.request


def openFile(jsonFilename):
    try:
        jsonFile = open(jsonFilename)
        jsonFile_str = jsonFile.read()
        testDictionary = json.loads(jsonFile_str)
    except:
        print("File not found: ", jsonFile)
    finally:
        jsonFile.close()
    return testDictionary


def getListFromDictionary(dictionary):
    return list(dictionary.values())[0]


def flattenList(listPassed):
    newList = []
    dupeList = []
    for dictionary in listPassed:
        for key in dictionary:
            if type(dictionary[key]) == str:
                urlString = dictionary[key]
                if urlString not in newList:
                    newList.append(urlString)
                elif urlString not in dupeList:
                    dupeList.append(urlString)
            elif type(dictionary[key]) == list:
                for string in dictionary[key]:
                    urlString = string
                    if urlString not in newList:
                        newList.append(urlString)
                    elif urlString not in dupeList:
                        dupeList.append(urlString)
    checkLists(newList, dupeList)


def checkLists(newListPassed, dupeListPassed):
    errorList = []
    successList = []
    for string in newListPassed:
        urlString = string
        try:
            urllib.request.urlopen(urlString)
            successList.append(urlString)
        except urllib.error.URLError as e:
            if e:
                errorList.append(urlString)
    print("Pages Tested:", newListPassed, end='')
    print()
    print()
    print("Skipped:", dupeListPassed, end='')
    print()
    print()
    print("Success:", successList, end='')
    print()
    print()
    print("Error:", errorList, end='')
    print()
    print()
    print()


print("Test Data: Internet 1")
print("---------------------")
dictionary_testData1 = openFile('testData_Internet1.json')
list_testData1 = getListFromDictionary(dictionary_testData1)
flattenList(list_testData1)


print("Test Data: Internet 2")
print("---------------------")
dictionary_testData2 = openFile('testData_Internet2.json')
list_testData2 = getListFromDictionary(dictionary_testData2)
flattenList(list_testData2)
